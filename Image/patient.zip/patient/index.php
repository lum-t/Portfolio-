					<?php 
          session_start(); 
							if(isset($_POST['submit'])){

						include './config/connection.php';

								$email = mysqli_real_escape_string($con, $_POST['email']);
								$password = mysqli_real_escape_string($con, $_POST['password']);

								$sql = "SELECT * FROM users WHERE email='$email' and password='$password'";

								$query = mysqli_query($con, $sql);

								if($row = mysqli_num_rows($query) > 0){
								
								$row = mysqli_fetch_array($query);
								$_SESSION['client_id'] = $row['client_id'];
								$_SESSION['id'] = $row["id"];
								$_SESSION['email'] = $row["email"];								
			   echo "<script> alert('Login Successful'); window.location='dashboard.php'; </script>";

								}else{
									echo "<div class='alert alert-danger'>Email or Password is Incorrect</div>";

								}

							}
							?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Login - Patient Management System</title>

  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
  <!-- icheck bootstrap -->
  <link rel="stylesheet" href="plugins/icheck-bootstrap/icheck-bootstrap.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/adminlte.min.css">

  <style>
  	
  	.login-box {
    	width: 430px;
	}
  
#system-logo {
    width: 5em !important;
    height: 5em !important;
    object-fit: cover;
    object-position: center center;
}
  </style>
</head>
<body class="hold-transition login-page dark-mode">
<div class="login-box">
  <div class="login-logo mb-4">
    <img src="dist/img/logo.jpg" class="img-thumbnail p-0 border rounded-circle" id="system-logo">
    <div class="text-center h2 mb-0">Patient Management System</div>
  </div>
  <!-- /.login-logo -->
  <div class="card card-outline card-primary rounded-0 shadow">
    <div class="card-body login-card-body">
      <p class="login-box-msg">Please enter your login credentials</p>
      <form method="post">
        <div class="input-group mb-3">
          <input type="text" class="form-control form-control-lg rounded-0 autofocus" 
          placeholder="Email" id="user_name" name="email">
          <div class="input-group-append">
            <div class="input-group-text">
              <span class="fas fa-user"></span>
            </div>
          </div>
        </div>
        <div class="input-group mb-3">
          <input type="password" class="form-control form-control-lg rounded-0" 
          placeholder="Password" id="password" name="password">
          <div class="input-group-append">
            <div class="input-group-text">
              <span class="fas fa-lock"></span>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-12">
            <button name="submit" type="submit" class="btn btn-primary rounded-0 btn-block">Sign In</button>
          </div>
          
          <!-- /.col -->
        </div> 
         </form><br>
 <div class="row">
          <div class="col-12">
            <a href="register.php">
            <button  type="submit" class="btn btn-primary rounded-0 btn-block">Register</button>
            </a>
          </div>
          
          <!-- /.col -->
        </div>
        <div class="row">
          <div class="col-md-12">
            <p class="text-danger">
         
            </p>
          </div>
        </div>
     

      
    </div>
    <!-- /.login-card-body -->
  </div>
</div>
<!-- /.login-box -->

<!-- jQuery -->

</body>
</html>
