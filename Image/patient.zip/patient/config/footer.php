<footer class="main-footer fixed-bottom">
    <strong>Copyright &copy; <?php echo date('Y');?> 
    <a href="./">Patient Management System</a>.</strong> All rights reserved.
    <div class="float-right d-sm-block">
      PMS Version 1.0
    </div>
  </footer>

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>