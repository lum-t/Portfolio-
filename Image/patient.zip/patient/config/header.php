<!-- Navbar -->
<nav class="main-header navbar navbar-expand navbar-dark navbar-light fixed-top">
  <!-- Left navbar links -->
  <ul class="navbar-nav">
    <li class="nav-item">
      <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
    </li>
  </ul>
  <a href="index3.html" class="navbar-brand">
    <span class="brand-text font-weight-light">Patient Management System </span>
</a>
  <!-- Right navbar links -->
  <ul class="navbar-nav ml-auto">
    <li class="nav-item">
              <?php   
session_start(); 

        $id = $_SESSION['client_id'];
      $sql = "SELECT * FROM users WHERE client_id='$id'";
      $query = mysqli_query($con, $sql);
      $row = mysqli_fetch_array($query);?>
    <div class="login-user text-light font-weight-bolder">Welcome, <?= $row['fname'] ?>!</div>  
    </li>
  </ul>
</nav>
<!-- /.navbar -->